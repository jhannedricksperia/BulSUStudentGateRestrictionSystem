<?php
// config.php - Firebase configuration
define("FIREBASE_DB_URL", "https://gatemanagementsystem-default-rtdb.asia-southeast1.firebasedatabase.app/");
?>

